clear;
load('Alpha5')

%figure(4);
%plot(alpha0);

%figure(5);
%plot(abs(alpha0));
% 
% it = alpha0;
% steigung = zeros(length(alpha0),1);
% k=10;
% 
% while k < length(alpha0)
%     steigung(k) =  ((it(k)-it(k-9)));
%     k = k+1;
% end;
%     
% figure(6);
% clf();
% hold on
% plot (steigung);
% plot(alpha0,'r');
% legend('steigung','signal');
% hold off
% 
% 
% figure(7);
% clf();
% hold on
% plot (abs(steigung));
% plot(abs(alpha0),'r');
% legend('steigung','signal');
% hold off


alpha = alphadetektor2(alpha0,50,15000,580)