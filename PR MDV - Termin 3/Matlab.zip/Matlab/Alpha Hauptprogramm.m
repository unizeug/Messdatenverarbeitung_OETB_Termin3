%alphahauptprogramm
%load Anschnitt_pi_2;
%figure(1)
%plot(alpha0);

%figure(2)
%plot(abs(alpha0));

figure(3)
plot(steigung)

figure(4)
plot(abs(steigung));








%alphadetektor(anschnitt_pi_2, 50, 6000, 176)
